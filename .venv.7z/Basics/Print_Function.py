print("How old are you ?", end=' ')
age = int(input())
print("How tall are you ?",end ='')
height = int(input())
print("How much weight are you ?",end='')
weight = float(input())

print(f"So, you're {age} old, {height} inches tall and {weight} kg's heavey.")