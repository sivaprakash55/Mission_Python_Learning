my_name = 'Siva Prakash'
my_age = 30
my_hieght = 74
my_weigth = 80
my_eyes = 'Black'
my_teeth = 'White'
my_hair = 'Black'

print(f"Let's talk about {my_name}")
print(f"He's {my_hieght} inches tall")
print(f"He's {my_weigth} pounds heavy")
total = my_age + my_hieght + my_weigth
print(f"If I add {my_age}, {my_hieght} and {my_weigth}. I get my {total} ")