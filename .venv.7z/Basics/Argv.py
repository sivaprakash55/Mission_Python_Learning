from sys import argv

argv = siva , anu ,saanvi

print("Father name: ",siva)