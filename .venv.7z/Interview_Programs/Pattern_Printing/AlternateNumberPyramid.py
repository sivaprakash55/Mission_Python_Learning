rows = 5
for i in range(rows+1):
    for j in range(i):
        print(i*2-1,end = " ")
    print("")

1
3 3
5 5 5
7 7 7 7
9 9 9 9 9