print("RightAngle Triangle Pattern Increment")
for i in range(1,6):
    print("*" * i,end='\n')

print("\nRightAngle Triangle Pattern Decrement")
for i in range(6,0,-1):
    print("*" * i , end ='\n')