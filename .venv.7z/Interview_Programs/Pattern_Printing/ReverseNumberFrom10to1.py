num = 5
row = 0
col= 0

for i in range(1,num):
    for j in range(i):
        row += 1
        print(row, end=' ')

    #row += 1
    #curr = j
    print(' ')