lst = [1,2,3,4,5,6,7,8]

print(f"Length of List using len() is {len(lst)}")

count = 0
for i in lst:
    count +=1
print(f"Lenght of lsit using Navie method {count}")