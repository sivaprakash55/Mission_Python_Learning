#using filter we can do this

list1 = ["Mike", "", "Emma", "Kelly", "", "Brad"]

res = list(filter(None,list1))
print(res)