# using sum()

lst = [10,20,30,40]
print("Sum of elements using sum() is :",sum(lst))

# Using loop
sum = 0
for i in lst:
    sum += i
print("sum of elements using for loop is :",sum)