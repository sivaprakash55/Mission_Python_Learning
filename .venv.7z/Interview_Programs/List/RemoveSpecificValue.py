#use for loop to iterate and use list comprehenstion to return result

list1 = [5, 20, 15, 20, 25, 50, 20]

print([i for i in list1 if i != 20])