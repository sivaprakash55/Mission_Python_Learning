lst1 = [10, 20, 30, 40, 50]
pos = [0, 2, 4]

print([lst1[i] for i in pos])